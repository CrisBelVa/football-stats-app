#!/usr/bin/env python
# coding: utf-8

# In[87]:


import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

file_path = '/Users/cristhianbeltran/Desktop/Sports Data Campus/Master Big Data aplicado al Scouting en Futbol/Proyecto Final/leagues_stats.csv'

df = pd.read_csv(file_path)


# In[ ]:


df.head()


# In[19]:


for league in df['league'].unique():
    plt.figure(figsize=(10, 6))

    # Filter the DataFrame for the current league
    league_df = df[df['league'] == league]

    # Create a scatter plot of xG vs. Goals for the current league
    sns.scatterplot(x='xG', y='GF', data=league_df, s=100)
    plt.title(f'xG vs. Goals for {league}')
    plt.xlabel('Expected Goals (xG)')
    plt.ylabel('Goals (GF)')
    plt.axline((0, 0), slope=1, linestyle='--', color='grey')  # line y=x for reference
    
    for i in range(league_df.shape[0]):
        plt.text(x=league_df['xG'].iloc[i] + 0.05, 
                 y=league_df['GF'].iloc[i], 
                 s=f"{league_df['Squad'].iloc[i]} ({league_df['year'].iloc[i]})",
                 fontsize=9)

    plt.show()


# In[21]:


# Set the figure size for the plot
plt.figure(figsize=(12, 8))

# Create a scatter plot of xG vs. Goals For (GF) across all leagues
sns.scatterplot(x='xG', y='GF', hue='league', style='league', data=df, s=100)

# Annotate each point with the team name and year
for i in range(df.shape[0]):
    plt.text(x=df['xG'].iloc[i] + 0.05, 
             y=df['GF'].iloc[i], 
             s=f"{df['Squad'].iloc[i]} ({df['year'].iloc[i]})", 
             fontsize=8)

# Add titles and labels
plt.title('xG vs. Goals For Across Leagues')
plt.xlabel('Expected Goals (xG)')
plt.ylabel('Goals For (GF)')
plt.axline((0, 0), slope=1, linestyle='--', color='grey')  # line y=x for reference
plt.legend(title='League')
plt.show()


# In[25]:


plt.figure(figsize=(12, 8))

# Calculate Goals per match and xG per match for each league
df['Goals per match'] = df['GF'] / df['MP']
df['xG per match'] = df['xG'] / df['MP']

# Create a scatter plot for Goals per match vs. xG per match, colored by league
sns.scatterplot(x='Goals per match', y='xG per match', hue='league', style='league', data=df, s=100)

# Annotate each point with the league name
for i in range(df.shape[0]):
    plt.text(x=df['Goals per match'].iloc[i] + 0.01, 
             y=df['xG per match'].iloc[i], 
             s=f"{df['Squad'].iloc[i]} ({df['year'].iloc[i]})", 
             fontsize=9)

# Add titles and labels
plt.title('Goals and xG per Match Across Leagues')
plt.xlabel('Goals per match')
plt.ylabel('xG per match')
plt.axline((0, 0), slope=1, linestyle='--', color='grey')  # line y=x for reference
plt.legend(title='League', loc='best')
plt.show()


# In[27]:


leagues_agg= df.groupby(['league', 'year']).agg({
    'GF': 'sum', 
    'xG': 'sum', 
    'MP': 'sum'
}).reset_index()

# Calculate Goals per match and xG per match for each league
league_agg['Goals per match'] = league_agg['GF'] / league_agg['MP']
league_agg['xG per match'] = league_agg['xG'] / league_agg['MP']

# Set the figure size
plt.figure(figsize=(12, 8))

# Create a scatter plot for Goals per match vs. xG per match, colored by league
sns.scatterplot(x='Goals per match', y='xG per match', hue='league', style='league', data=league_agg, s=100)

# Annotate each point with the league name and year
for i in range(league_agg.shape[0]):
    plt.text(x=league_agg['Goals per match'].iloc[i] + 0.01, 
             y=league_agg['xG per match'].iloc[i], 
             s=f"{league_agg['league'].iloc[i]} ({league_agg['year'].iloc[i]})", 
             fontsize=9)

# Add titles and labels
plt.title('Goals and xG per Match Across Leagues')
plt.xlabel('Goals per match')
plt.ylabel('xG per match')
plt.axline((0, 0), slope=1, linestyle='--', color='grey')  # line y=x for reference
plt.legend(title='League', loc='best')
plt.show()


# In[73]:


df['GF_per_90'] = df['GF'] / df['MP']
df['GA_per_90'] = df['GA'] / df['MP']

plt.figure(figsize=(10, 6))

# Create a scatter plot of GF per 90 vs GA per 90 with color based on league
sns.scatterplot(x='GF_per_90', y='GA_per_90', hue='league', data=df, s=100)

# Annotate each point with the team name and year
for i in range(df.shape[0]):
    plt.text(x=df['GF_per_90'].iloc[i] + 0.01, 
             y=df['GA_per_90'].iloc[i], 
             s=f"{df['Squad'].iloc[i]} ({df['year'].iloc[i]})", 
             fontsize=9)

# Add titles and labels
plt.title('Goals For vs Goals Against per 90 Minutes Across Teams')
plt.xlabel('Goals For per 90 minutes (GF/90)')
plt.ylabel('Goals Against per 90 minutes (GA/90)')
plt.show()


# In[83]:


df['Pts_per_MP'] = df['Pts'] / df['MP']

plt.figure(figsize=(12, 8))
sns.boxplot(x='league', y='Pts_per_MP', data=df)
plt.title('Distribution of Points per Match by League')
plt.xlabel('League')
plt.ylabel('Points per Match')
plt.xticks(rotation=45)
plt.show()


# In[85]:


plt.figure(figsize=(12, 8))
sns.boxplot(x='league', y='GF_per_90', data=df)
plt.title('Distribution of Goals For per 90 Minutes by League')
plt.xlabel('League')
plt.ylabel('Goals For per 90 minutes (GF/90)')
plt.xticks(rotation=45)
plt.show()


# In[100]:


league_year_avg = df.groupby(['league', 'year']).agg({
    'GF': 'mean', 
    'xG': 'mean'
}).reset_index()

plt.figure(figsize=(14, 8))

# Plot xG over time for each league
sns.lineplot(x='year', y='xG', hue='league', data=league_year_avg, marker='o', linestyle='--')
plt.title('Average xG Over Time by League')
plt.xlabel('Year')
plt.ylabel('Average xG')
plt.legend(title='League')
plt.show()


# In[ ]:


df['xG/MP'] = df['xG'] / df['MP']


# In[102]:


league_year_avg = df.groupby(['league', 'year']).agg({
    'xG': 'sum', 
    'MP': 'sum'
}).reset_index()

# Calculate xG per match
league_year_avg['xG_per_match'] = league_year_avg['xG'] / league_year_avg['MP']

plt.figure(figsize=(14, 8))

# Plot xG per match over time for each league
sns.lineplot(x='year', y='xG_per_match', hue='league', data=league_year_avg, marker='o', linestyle='--')
plt.title('Average xG per Match Over Time by League')
plt.xlabel('Year')
plt.ylabel('Average xG per Match')
plt.legend(title='League')
plt.show()


# In[104]:


league_year_avg = df.groupby(['league', 'year']).agg({
    'GF': 'sum', 
    'MP': 'sum'
}).reset_index()

# Calculate Goals per match
league_year_avg['GF_per_match'] = league_year_avg['GF'] / league_year_avg['MP']

plt.figure(figsize=(14, 8))

# Plot Goals per match over time for each league
sns.lineplot(x='year', y='GF_per_match', hue='league', data=league_year_avg, marker='o', linestyle='--')
plt.title('Average Goals per Match Over Time by League')
plt.xlabel('Year')
plt.ylabel('Average Goals per Match')
plt.legend(title='League')
plt.show()

