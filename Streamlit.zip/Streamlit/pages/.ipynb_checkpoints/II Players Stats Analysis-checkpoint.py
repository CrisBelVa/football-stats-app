import streamlit as st
import pandas as pd
import plotly.express as px
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Load your data
df = pd.read_csv('players_stats_final.csv')  # Replace with the path to your data file

# Sidebar for filters
st.sidebar.header('Filters')
selected_season = st.sidebar.selectbox('Select Season', df['Year'].unique())
selected_league = st.sidebar.selectbox('Select League', df['league'].unique())
selected_position = st.sidebar.multiselect('Select Position', df['Pos'].unique(), default=df['Pos'].unique())

# Apply filters
filtered_data = df[
    (df['Yeat'] == selected_season) & 
    (df['League'] == selected_league) & 
    (df['Pos'].isin(selected_position))
]

st.title('Football Player Stats Dashboard')
st.subheader('Generic Metrics with PCA Clustering')

# Show the filtered data
st.dataframe(filtered_data.head())



st.subheader('Player Performance Metrics')

# Display key metrics using metric component
st.metric(label="Goals", value=int(player_data['Gls'].sum()))
st.metric(label="Assists", value=int(player_data['Ast'].sum()))
st.metric(label="Expected Goals (xG)", value=round(player_data['xG'].sum(), 2))
st.metric(label="Expected Assists (xAG)", value=round(player_data['xAG'].sum(), 2))

# Visualization: Radar chart or bar chart for player metrics
fig = px.bar(
    player_data,
    x=['Gls', 'Ast', 'Min', 'xG', 'xAG'],  # Adjust to include more metrics
    y=player_data.iloc[0][['Gls', 'Ast', 'Min', 'xG', 'xAG']].values,
    labels={'x': 'Metrics', 'y': 'Values'},
    title=f'Metrics for {selected_player}'
)
st.plotly_chart(fig)